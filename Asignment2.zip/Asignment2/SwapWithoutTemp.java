
//19.How to Swap two Strings without using third (temporary) variable?

public class SwapWithoutTemp 
{  
    public static void main(String args[])
	{  
        String a = "cdac";  
		
        String b = "velocity";  
        System.out.println("Before swap: " + a + " " + b);  
        a = a + b;  
        b = a.substring(0, a.length() - b.length());  
        a = a.substring(b.length());  
        System.out.println("After : " + a + " " + b);  
    }  
}  